# Nguyen Viet Hoang - Portfolio Website

This is a React + Tailwind CSS personal portfolio website, designed and built by Nguyen Viet Hoang.

## Features

- Dark/Light mode support
- Project showcase section
- Contact information

## Deploy

This site is set up to be deployed with GitHub Pages using the `gh-pages` branch.

## Build & Deploy

```bash
npm install
npm run build
npm run deploy
```
